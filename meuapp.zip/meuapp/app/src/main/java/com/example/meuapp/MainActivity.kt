package com.example.meuapp

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.tooling.preview.Preview
import com.example.meuapp.ui.theme.MeuappTheme
import com.example.meuapp.view.MainGuiViewModel

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
                val meuViewModel = MainGuiViewModel()
        enableEdgeToEdge()
        setContent {
            ProjMVVMTheme{
                Scaffold(modifier = Modifier.fillMaxSize()) { innerPadding ->
                    MainGui(meuViewModel)
                }
            }
        }
