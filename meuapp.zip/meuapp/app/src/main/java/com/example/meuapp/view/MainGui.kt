package com.example.meuapp.view

import androidx.compose.material3.Text
import androidx.compose.material3.TextField
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember

@Composable
fun <MainGuiViewModel0> ManGui(meuViewmodel: MainGuiViewModel0){
    
    val x: Int by meuViewmodel.contador.observeAsState(0)
    
    var txfieldValue by remember {
        mutableStateOf()
    }
    
    column{
        Text(text = "Olá")
        TextField(value = x.toString(), onValueChange = {}
    )
        Button(onClick = {
            meuViewmodel.incrementContador()
        }) {
            Text(text = "NumClick = " + x.toString())
        }
}

