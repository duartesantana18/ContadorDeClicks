package com.example.meuapp.view

import android

class MainGuiViewModel : ViewModel() {
    private val _contador = MutableStateOf<int>(0)
    var contador = _contador

    fun incrementContador(){
        _contador.value = _contador.value?.plus(1)
    }
}